package com.demo.model;

public class HelloWorld {
  public void sayHello() {
	  System.out.println("Hello World!!!!");
  }
  public HelloWorld() {
	  System.out.println("In Hello world constructor");
  }
  
}
